// graph_analysis.rs
use std::collections::{HashMap, VecDeque};


    pub fn calculate_average_distance(graph: &HashMap<u32, Vec<u32>>) -> f64 {
    let mut total_distance = 0;
    let mut total_pairs = 0;

    for (source_node, _) in graph {
        let distances = bfs_distances(&graph, *source_node);

        // exclude unreachable nodes
        let reachable_distances: Vec<u32> = distances
            .iter()
            .filter(|(_, distance)| *distance < &u32::MAX)
            .map(|(_, distance)| *distance)
            .collect();

        // accumulate distances
        total_distance += reachable_distances.iter().sum::<u32>();
        total_pairs += reachable_distances.len();
    }

    // calculate average distance
    if total_pairs > 0 {
        total_distance as f64 / total_pairs as f64
    } else {
        0.0
    }
}

fn bfs_distances(graph: &HashMap<u32, Vec<u32>>, start_node: u32) -> HashMap<u32, u32> {
    let mut distances: HashMap<u32, u32> = graph.keys().map(|&node| (node, std::u32::MAX)).collect();
    let mut queue = VecDeque::new();

    // initialize starting node
    distances.insert(start_node, 0);
    queue.push_back(start_node);

    while let Some(current_node) = queue.pop_front() {
        for &neighbor in &graph[&current_node] {
            if distances[&neighbor] == u32::MAX {
                distances.insert(neighbor, distances[&current_node] + 1);
                queue.push_back(neighbor);
            }
        }
    }

    distances
}

pub fn six_degrees_of_separation(graph: &HashMap<u32, Vec<u32>>, start_node: u32, end_node: u32, max_degrees: u32) -> bool {
    let mut visited_nodes = HashMap::new();
    visited_nodes.insert(start_node, 0);

    let mut queue = VecDeque::new();
    queue.push_back(start_node);

    while let Some(current_node) = queue.pop_front() {
        for &neighbor in &graph[&current_node] {
            if !visited_nodes.contains_key(&neighbor) {
                visited_nodes.insert(neighbor, visited_nodes[&current_node] + 1);

                if neighbor == end_node {
                    return visited_nodes[&neighbor] <= max_degrees;
                }

                if visited_nodes[&neighbor] < max_degrees {
                    queue.push_back(neighbor);
                }
            }
        }
    }

    false
}

pub fn compute_relationship_strength(graph: &HashMap<u32, Vec<u32>>) -> HashMap<(u32, u32), usize> {
    let mut relationship_strength = HashMap::new();

    for (&node, neighbors) in graph {
        for &friend in neighbors {
            // Check if there's a mutual connection
            if let Some(mutual_friends) = graph.get(&friend) {
                let mutual_friends_count = mutual_friends
                    .iter()
                    .filter(|&f| graph[&node].contains(f))
                    .count();

                relationship_strength.insert((node, friend), mutual_friends_count);
            }
        }
    }

    relationship_strength
}
